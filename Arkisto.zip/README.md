# FYFYSWAP — The DEX for the Interoperable Future.
Cross-chain exchange of assets, simple creation and listing of new assets, and the easiest swaps ever. The interoperable future of FYFY is here and we are at the forefront!

![Sample](fyfywap-share-image.jpg)
